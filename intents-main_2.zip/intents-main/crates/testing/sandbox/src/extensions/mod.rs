pub mod acl;
pub mod mt_receiver;
pub mod nft;
pub mod wnear;
// TODO: remove when mt will be part of near kit extensions
pub mod mt;

#[cfg(feature = "defuse")]
pub mod defuse;
#[cfg(feature = "escrow")]
pub mod escrow;
#[cfg(feature = "deployer")]
pub mod global_deployer;
#[cfg(feature = "outlayer")]
pub mod outlayer_app;
#[cfg(feature = "poa")]
pub mod poa;
#[cfg(feature = "wallet")]
pub mod wallet;

use crate::outcome::SuccessfulExecutionOutcome;
use anyhow::Result;
use near_kit::{AccountId, Final, FunctionCall, Near};

pub trait FnCallTransaction {
    async fn fn_call(
        &self,
        contract: impl Into<AccountId>,
        action: FunctionCall,
    ) -> Result<SuccessfulExecutionOutcome>;
}

impl FnCallTransaction for Near {
    async fn fn_call(
        &self,
        contract: impl Into<AccountId>,
        action: FunctionCall,
    ) -> Result<SuccessfulExecutionOutcome> {
        self.transaction(contract.into())
            .add_action(action)
            .wait_until::<Final>()
            .await?
            .try_into()
    }
}
