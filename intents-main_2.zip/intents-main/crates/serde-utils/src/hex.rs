use derive_more::From;
use serde::{Deserialize, Serialize};
use serde_with::{hex::Hex, serde_as};

/// An helper wrapper for [`Hex`] adaptor needed for `#[near]`-annotated impl blocks,
/// since `#[near_bindgen]` doesn't support `#[serde(...)]` attributes on method arguments
#[serde_as]
#[cfg_attr(
    feature = "schemars-v0_8",
    derive(::schemars::JsonSchema),
    schemars(transparent)
)]
#[derive(Debug, Clone, Copy, Default, Serialize, Deserialize, From)]
#[serde(bound(serialize = "T: AsRef<[u8]>", deserialize = "T: TryFrom<Vec<u8>>"))]
#[repr(transparent)]
pub struct AsHex<T>(#[serde_as(as = "Hex")] pub T);

impl<T> AsHex<T> {
    #[inline]
    pub fn into_inner(self) -> T {
        self.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json;

    #[test]
    fn serialize_vec() {
        let val = AsHex(vec![0xde, 0xad, 0xbe, 0xef]);
        let json = serde_json::to_string(&val).unwrap();
        assert_eq!(json, r#""deadbeef""#);
    }

    #[test]
    fn deserialize_vec() {
        let val: AsHex<Vec<u8>> = serde_json::from_str(r#""deadbeef""#).unwrap();
        assert_eq!(val.0, vec![0xde, 0xad, 0xbe, 0xef]);
    }

    #[test]
    fn roundtrip_vec() {
        let original = vec![0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
        let wrapped = AsHex(original.clone());
        let json = serde_json::to_string(&wrapped).unwrap();
        let recovered: AsHex<Vec<u8>> = serde_json::from_str(&json).unwrap();
        assert_eq!(recovered.0, original);
    }

    #[test]
    fn serialize_fixed_array() {
        let val = AsHex([0xff, 0x00, 0xab]);
        let json = serde_json::to_string(&val).unwrap();
        assert_eq!(json, r#""ff00ab""#);
    }

    #[test]
    fn deserialize_fixed_array() {
        let val: AsHex<[u8; 3]> = serde_json::from_str(r#""ff00ab""#).unwrap();
        assert_eq!(val.0, [0xff, 0x00, 0xab]);
    }

    #[test]
    fn empty_bytes() {
        let val = AsHex(Vec::<u8>::new());
        let json = serde_json::to_string(&val).unwrap();
        assert_eq!(json, r#""""#);

        let recovered: AsHex<Vec<u8>> = serde_json::from_str(&json).unwrap();
        assert!(recovered.0.is_empty());
    }

    #[test]
    fn into_inner() {
        let data = vec![1, 2, 3];
        let wrapped = AsHex(data.clone());
        assert_eq!(wrapped.into_inner(), data);
    }

    #[test]
    fn from_impl() {
        let data = vec![1, 2, 3];
        let wrapped: AsHex<Vec<u8>> = data.clone().into();
        assert_eq!(wrapped.0, data);
    }

    #[test]
    fn deserialize_uppercase_input() {
        let val: AsHex<Vec<u8>> = serde_json::from_str(r#""DEADBEEF""#).unwrap();
        assert_eq!(val.0, vec![0xde, 0xad, 0xbe, 0xef]);
    }

    #[test]
    fn deserialize_mixed_case_input() {
        let val: AsHex<Vec<u8>> = serde_json::from_str(r#""DeAdBeEf""#).unwrap();
        assert_eq!(val.0, vec![0xde, 0xad, 0xbe, 0xef]);
    }

    #[test]
    fn deserialize_invalid_hex() {
        let result = serde_json::from_str::<AsHex<Vec<u8>>>(r#""xyz""#);
        assert!(result.is_err());
    }

    #[test]
    fn deserialize_odd_length() {
        let result = serde_json::from_str::<AsHex<Vec<u8>>>(r#""abc""#);
        assert!(result.is_err());
    }

    #[test]
    fn deserialize_wrong_length_for_fixed_array() {
        let result = serde_json::from_str::<AsHex<[u8; 4]>>(r#""deadbeefaa""#);
        assert!(result.is_err());
    }
}
