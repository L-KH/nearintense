use crate::{AccountIdRef, Nonce, Timestamp, events::DefuseEvent};
use impl_tools::autoimpl;

#[autoimpl(for <T: trait + ?Sized> &mut T, Box<T>)]
pub trait Inspector {
    fn on_deadline(&mut self, deadline: Timestamp);

    fn on_event(&mut self, event: DefuseEvent<'_>);

    fn on_intent_executed(&mut self, signer_id: &AccountIdRef, hash: [u8; 32], nonce: Nonce);
}
