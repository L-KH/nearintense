use crate::{
    AccountId,
    engine::deltas::InvariantViolated,
    public_key::PublicKey,
    token_id::{TokenId, TokenIdError, nep171::Nep171TokenId},
    tokens::{BATCH_MAX_TOKENS, MAX_TOKEN_ID_LEN},
};
use defuse_nep245::ErrorLogTooLong;

pub type Result<T, E = DefuseError> = ::core::result::Result<T, E>;

#[cfg_attr(feature = "near-contract", derive(::near_sdk::FunctionError))]
#[derive(Debug, thiserror::Error)]
pub enum DefuseError {
    #[error("account '{0}' not found")]
    AccountNotFound(AccountId),

    #[error("account '{0}' is locked")]
    AccountLocked(AccountId),

    #[error("authentication by PREDECESSOR_ID is disabled for account '{0}'")]
    AuthByPredecessorIdDisabled(AccountId),

    #[error("insufficient balance or overflow")]
    BalanceOverflow,

    #[error("deadline has expired")]
    DeadlineExpired,

    #[error("deadline is greater than nonce")]
    DeadlineGreaterThanNonce,

    #[error("gas overflow")]
    GasOverflow,

    #[error("invalid intent")]
    InvalidIntent,

    #[error("invalid signature")]
    InvalidSignature,

    #[error(
        "invariant violated: {}",
        serde_json::to_string(.0).unwrap_or_else(|_| unreachable!())
    )]
    InvariantViolated(InvariantViolated),

    #[error("JSON: {0}")]
    JSON(#[from] serde_json::Error),

    #[error("NFT '{}' is already deposited", TokenId::Nep171(.0.clone()))]
    NftAlreadyDeposited(Nep171TokenId),

    #[error("nonce was already used")]
    NonceUsed,

    #[error("nonce was already expired")]
    NonceExpired,

    #[error("invalid nonce")]
    InvalidNonce,

    #[error("public key '{1}' already exists for account '{0}'")]
    PublicKeyExists(AccountId, PublicKey),

    #[error("public key '{1}' doesn't exist for account '{0}'")]
    PublicKeyNotExist(AccountId, PublicKey),

    #[error("token_id: {0}")]
    ParseTokenId(#[from] TokenIdError),

    #[error("wrong verifying_contract")]
    WrongVerifyingContract,

    #[error("invalid salt")]
    InvalidSalt,

    #[error("maximum attempts to generate a new salt reached")]
    SaltGenerationFailed,

    #[error("token_id is too long: max length is {MAX_TOKEN_ID_LEN}, got {0}")]
    TokenIdTooLarge(usize),

    #[error(transparent)]
    LogTooLong(#[from] ErrorLogTooLong),

    #[error("too many tokens: max batch size is {BATCH_MAX_TOKENS}, got {0}")]
    TooManyTokens(usize),
}
