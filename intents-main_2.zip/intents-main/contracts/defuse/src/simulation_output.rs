use defuse_core::{
    Result, Salt, Timestamp,
    accounts::{AccountEvent, NonceEvent},
    engine::deltas::InvariantViolated,
    fees::Pips,
    intents::MaybeIntentEvent,
};

use serde::{Deserialize, Serialize};

#[cfg_attr(feature = "abi", derive(::schemars::JsonSchema))]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationReport {
    pub intents_executed: Vec<MaybeIntentEvent<AccountEvent<'static, NonceEvent>>>,
    pub logs: Vec<String>,
    pub min_deadline: Timestamp,
}

#[cfg_attr(feature = "abi", derive(::schemars::JsonSchema))]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationOutput {
    #[serde(flatten)]
    pub report: SimulationReport,

    /// Unmatched token deltas needed to keep the invariant.
    /// If not empty, can be used along with fee to calculate `token_diff` closure.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub invariant_violated: Option<InvariantViolated>,

    /// Additional info about current state
    pub state: StateOutput,
}

impl SimulationOutput {
    pub fn into_result(self) -> Result<(), InvariantViolated> {
        if let Some(unmatched_deltas) = self.invariant_violated {
            return Err(unmatched_deltas);
        }
        Ok(())
    }
}

#[cfg_attr(feature = "abi", derive(::schemars::JsonSchema))]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StateOutput {
    pub fee: Pips,

    pub current_salt: Salt,
}
