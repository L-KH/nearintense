#![cfg_attr(not(near), allow(dead_code))]

#[cfg(feature = "auth_call")]
mod auth_call;
mod cleanup;
mod close;
mod fill;
mod fund;
mod lost_found;
mod resolve;
mod return_value;
mod tokens;

use impl_tools::autoimpl;
use near_sdk::{FunctionError, PanicOnDefault, PromiseOrValue, env, near};

use crate::{ContractStorage, Error, Escrow, Params, Result, Storage};

#[near(contract_state(key = ContractStorage::STATE_KEY))]
#[autoimpl(Deref using self.0)]
#[derive(Debug, PanicOnDefault)]
pub struct Contract(ContractStorage);

#[near]
impl Escrow for Contract {
    fn es_view(&self) -> &Storage {
        self.try_as_alive()
            // if cleanup is in progress, the contract will be
            // soon deleted anyway, so it's ok to panic here
            .unwrap_or_else(|err| err.panic())
    }

    fn es_close(&mut self, params: Params) -> PromiseOrValue<bool> {
        self.close(&env::predecessor_account_id(), params)
            .unwrap_or_else(|err| err.panic())
    }

    fn es_lost_found(&mut self, params: Params) -> PromiseOrValue<bool> {
        self.lost_found(params).unwrap_or_else(|err| err.panic())
    }
}

impl ContractStorage {
    #[inline]
    const fn as_alive(&self) -> Option<&Storage> {
        self.0.as_ref()
    }

    #[inline]
    fn try_as_alive(&self) -> Result<&Storage> {
        self.as_alive().ok_or(Error::CleanupInProgress)
    }
}
