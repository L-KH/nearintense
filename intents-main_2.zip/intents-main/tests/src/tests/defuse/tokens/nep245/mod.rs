mod letter_gen;
mod mt_deposit_resolve_gas;
mod mt_transfer_resolve_gas;

use std::future::Future;

/// Binary search to find the maximum value for which `test` succeeds.
pub(super) async fn binary_search_max<F, Fut>(low: usize, high: usize, test: F) -> Option<usize>
where
    F: Fn(usize) -> Fut,
    Fut: Future<Output = anyhow::Result<()>>,
{
    let mut lo = low;
    let mut hi = high;
    let mut best = None;

    while lo <= hi {
        let mid = lo + (hi - lo) / 2;
        match test(mid).await {
            Ok(()) => {
                best = Some(mid);
                lo = mid + 1; // success -> try higher
            }
            Err(_) => {
                hi = mid - 1; // failure -> try lower
            }
        }
    }

    best
}

use std::borrow::Cow;

use defuse_fees::Pips;
use defuse_near_utils::REFUND_MEMO;
use defuse_sandbox::{
    account::Account,
    extensions::{
        defuse::{
            Defuse, DefuseDeployerExt, DefuseExt, DefuseSignerExt,
            contract::config::{DefuseConfig, RolesConfig},
            core::{
                amounts::Amounts,
                fees::FeesConfig,
                intents::tokens::{NotifyOnTransfer, Transfer},
                token_id::{TokenId, nep141::Nep141TokenId, nep245::Nep245TokenId},
            },
            nep245::{MtBurnEvent, MtEvent, MtTransferEvent, Token},
            tokens::{DepositAction, DepositMessage, ExecuteIntents},
        },
        mt::{Mt, MtBalanceOfArgs},
    },
    kit::NearToken,
};
use defuse_test_utils::wasms::{DEFUSE_WASM, MT_RECEIVER_STUB_WASM};
use multi_token_receiver_stub::MTReceiverMode as StubAction;
use near_sdk::{events::AsNep297Event, json_types::U128};

use crate::{
    sandbox::extensions::mt::MtExt,
    tests::{
        defuse::env::{Env, env},
        utils::assert_a_contains_b,
    },
};
use rstest::rstest;

#[rstest]
#[tokio::test]
async fn multitoken_enumeration(#[future(awt)] env: Env) {
    let (user1, user2, user3, ft1, ft2) = futures::join!(
        env.create_user(),
        env.create_user(),
        env.create_user(),
        env.create_token(),
        env.create_token()
    );

    env.initial_ft_storage_deposit(
        vec![user1.account_id(), user2.account_id()],
        vec![ft1.contract_id(), ft2.contract_id()],
    )
    .await;

    // Check already existing tokens from persistent state if it was applied
    let existing_tokens = env.mt_tokens(env.defuse.contract_id(), ..).await.unwrap();

    {
        assert_eq!(
            env.mt_tokens(env.defuse.contract_id(), ..).await.unwrap(),
            existing_tokens
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user2.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user3.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
    }

    env.defuse_ft_deposit_to(ft1.contract_id(), 1000, user1.account_id(), None)
        .await
        .unwrap();

    let ft1_id = TokenId::from(Nep141TokenId::new(ft1.contract_id().clone()));
    let ft2_id = TokenId::from(Nep141TokenId::new(ft2.contract_id().clone()));

    let from_token_index = existing_tokens.len();

    {
        assert_eq!(
            env.mt_tokens(env.defuse.contract_id(), from_token_index..)
                .await
                .unwrap(),
            [Token {
                token_id: ft1_id.to_string(),
                owner_id: None
            }]
        );
        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap(),
            [Token {
                token_id: ft1_id.to_string(),
                owner_id: None
            }]
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user2.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user3.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
    }

    env.defuse_ft_deposit_to(ft1.contract_id(), 2000, user2.account_id(), None)
        .await
        .unwrap();

    {
        assert_eq!(
            env.mt_tokens(env.defuse.contract_id(), from_token_index..)
                .await
                .unwrap(),
            [Token {
                token_id: ft1_id.to_string(),
                owner_id: None
            }]
        );
        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap(),
            [Token {
                token_id: ft1_id.to_string(),
                owner_id: None
            }]
        );
        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user2.account_id(), ..)
                .await
                .unwrap(),
            [Token {
                token_id: ft1_id.to_string(),
                owner_id: None
            }]
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user3.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
    }

    env.defuse_ft_deposit_to(ft2.contract_id(), 5000, user1.account_id(), None)
        .await
        .unwrap();

    {
        assert_eq!(
            env.mt_tokens(env.defuse.contract_id(), from_token_index..)
                .await
                .unwrap(),
            [
                Token {
                    token_id: ft1_id.to_string(),
                    owner_id: None
                },
                Token {
                    token_id: ft2_id.to_string(),
                    owner_id: None
                }
            ]
        );
        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap(),
            [
                Token {
                    token_id: ft1_id.to_string(),
                    owner_id: None
                },
                Token {
                    token_id: ft2_id.to_string(),
                    owner_id: None
                }
            ]
        );
        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user2.account_id(), ..)
                .await
                .unwrap(),
            [Token {
                token_id: ft1_id.to_string(),
                owner_id: None
            }]
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user3.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
    }

    // Going back to zero available balance won't make it appear in mt_tokens
    assert_eq!(
        user1
            .defuse_ft_withdraw(
                env.defuse.contract_id(),
                ft1.contract_id(),
                user1.account_id(),
                1000,
                None,
                None,
            )
            .await
            .unwrap()
            .1,
        1000
    );
    assert_eq!(
        user2
            .defuse_ft_withdraw(
                env.defuse.contract_id(),
                ft1.contract_id(),
                user2.account_id(),
                2000,
                None,
                None
            )
            .await
            .unwrap()
            .1,
        2000
    );

    {
        assert_eq!(
            env.mt_tokens(env.defuse.contract_id(), from_token_index..)
                .await
                .unwrap(),
            [Token {
                token_id: ft2_id.to_string(),
                owner_id: None
            }]
        );
        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap(),
            [Token {
                token_id: ft2_id.to_string(),
                owner_id: None
            }]
        );
        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user2.account_id(), ..)
                .await
                .unwrap(),
            []
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user3.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
    }

    // Withdraw back everything left for user1, and we're back to the initial state
    assert_eq!(
        user1
            .defuse_ft_withdraw(
                env.defuse.contract_id(),
                ft2.contract_id(),
                user1.account_id(),
                5000,
                None,
                None
            )
            .await
            .unwrap()
            .1,
        5000
    );

    {
        assert_eq!(
            env.mt_tokens(env.defuse.contract_id(), ..).await.unwrap(),
            existing_tokens
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user2.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user3.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
    }
}

#[rstest]
#[tokio::test]
async fn multitoken_enumeration_with_ranges(#[future(awt)] env: Env) {
    let (user1, user2, user3, ft1, ft2, ft3) = futures::join!(
        env.create_user(),
        env.create_user(),
        env.create_user(),
        env.create_token(),
        env.create_token(),
        env.create_token()
    );

    env.initial_ft_storage_deposit(
        vec![user1.account_id()],
        vec![ft1.contract_id(), ft2.contract_id(), ft3.contract_id()],
    )
    .await;

    // Check already existing tokens from persistent state if it was applied
    let existing_tokens = env.mt_tokens(env.defuse.contract_id(), ..).await.unwrap();

    {
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user2.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user3.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
    }

    env.defuse_ft_deposit_to(ft1.contract_id(), 1000, user1.account_id(), None)
        .await
        .unwrap();
    env.defuse_ft_deposit_to(ft2.contract_id(), 2000, user1.account_id(), None)
        .await
        .unwrap();
    env.defuse_ft_deposit_to(ft3.contract_id(), 3000, user1.account_id(), None)
        .await
        .unwrap();

    let ft1_id = TokenId::from(Nep141TokenId::new(ft1.contract_id().clone()));
    let ft2_id = TokenId::from(Nep141TokenId::new(ft2.contract_id().clone()));
    let ft3_id = TokenId::from(Nep141TokenId::new(ft3.contract_id().clone()));

    {
        let expected = [
            Token {
                token_id: ft1_id.to_string(),
                owner_id: None,
            },
            Token {
                token_id: ft2_id.to_string(),
                owner_id: None,
            },
            Token {
                token_id: ft3_id.to_string(),
                owner_id: None,
            },
        ];

        let from_token = existing_tokens.len();

        assert_eq!(
            env.mt_tokens(env.defuse.contract_id(), from_token..)
                .await
                .unwrap(),
            expected[..]
        );

        for i in 0..=expected.len() {
            assert_eq!(
                env.mt_tokens(env.defuse.contract_id(), from_token + i..)
                    .await
                    .unwrap(),
                expected[i..]
            );
        }

        for start in 0..expected.len() - 1 {
            for end in start..=expected.len() {
                assert_eq!(
                    env.mt_tokens(
                        env.defuse.contract_id(),
                        from_token + start..from_token + end
                    )
                    .await
                    .unwrap(),
                    expected[start..end]
                );
            }
        }
    }

    {
        let expected = [
            Token {
                token_id: ft1_id.to_string(),
                owner_id: None,
            },
            Token {
                token_id: ft2_id.to_string(),
                owner_id: None,
            },
            Token {
                token_id: ft3_id.to_string(),
                owner_id: None,
            },
        ];

        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap(),
            expected[..]
        );

        assert_eq!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap(),
            expected[..]
        );

        for i in 0..=3 {
            assert_eq!(
                env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), i..)
                    .await
                    .unwrap(),
                expected[i..]
            );
        }

        for i in 0..=3 {
            assert_eq!(
                env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..i)
                    .await
                    .unwrap(),
                expected[..i]
            );
        }

        for i in 1..=3 {
            assert_eq!(
                env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), 1..i)
                    .await
                    .unwrap(),
                expected[1..i]
            );
        }

        for i in 2..=3 {
            assert_eq!(
                env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), 2..i)
                    .await
                    .unwrap(),
                expected[2..i]
            );
        }
    }
}

#[rstest]
#[tokio::test]
async fn multitoken_withdrawals(#[future(awt)] env: Env) {
    let (user1, user2, user3, ft1, ft2, ft3) = futures::join!(
        env.create_user(),
        env.create_user(),
        env.create_user(),
        env.create_token(),
        env.create_token(),
        env.create_token()
    );

    env.initial_ft_storage_deposit(
        vec![user1.account_id()],
        vec![ft1.contract_id(), ft2.contract_id(), ft3.contract_id()],
    )
    .await;

    // Check already existing tokens from persistent state if it was applied
    let existing_tokens = env.mt_tokens(env.defuse.contract_id(), ..).await.unwrap();

    let defuse2 = env
        .deploy_defuse(
            "defuse2",
            DefuseConfig {
                wnear_id: env.wnear.contract_id().clone(),
                fees: FeesConfig {
                    fee: Pips::ZERO,
                    fee_collector: env.account_id().clone(),
                },
                roles: RolesConfig::default(),
            },
            DEFUSE_WASM.clone(),
        )
        .await;

    {
        assert_eq!(
            env.mt_tokens(env.defuse.contract_id(), ..).await.unwrap(),
            existing_tokens
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user1.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user2.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
        assert!(
            env.mt_tokens_for_owner(env.defuse.contract_id(), user3.account_id(), ..)
                .await
                .unwrap()
                .is_empty(),
        );
    }

    env.defuse_ft_deposit_to(ft1.contract_id(), 1000, user1.account_id(), None)
        .await
        .unwrap();

    env.defuse_ft_deposit_to(ft2.contract_id(), 5000, user1.account_id(), None)
        .await
        .unwrap();

    env.defuse_ft_deposit_to(ft3.contract_id(), 8000, user1.account_id(), None)
        .await
        .unwrap();

    env.defuse_ft_deposit_to(ft1.contract_id(), 1000, user2.account_id(), None)
        .await
        .unwrap();

    env.defuse_ft_deposit_to(ft2.contract_id(), 5000, user2.account_id(), None)
        .await
        .unwrap();

    env.defuse_ft_deposit_to(ft3.contract_id(), 8000, user2.account_id(), None)
        .await
        .unwrap();

    let ft1_id = TokenId::Nep141(Nep141TokenId::new(ft1.contract_id().clone()));
    let ft2_id = TokenId::Nep141(Nep141TokenId::new(ft2.contract_id().clone()));
    let ft3_id = TokenId::Nep141(Nep141TokenId::new(ft3.contract_id().clone()));

    let defuse2_mt = env.contract::<Mt>(defuse2.account_id());

    // At this point, user1 in defuse2, has no balance of `"nep245:defuse.test.near:nep141:ft1.test.near"`, and others. We will fund it next.
    {
        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft1_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            0
        );

        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft2_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            0
        );

        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft3_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            0
        );
    }

    // Do an mt_transfer_call, and the message is of type DepositMessage, which will contain the user who will own the tokens in defuse2
    {
        user1
            .mt_transfer_call(
                env.defuse.contract_id(),
                defuse2.account_id(),
                ft1_id.to_string(),
                100,
                None,
                user1.account_id().to_string(),
            )
            .await
            .unwrap();

        user1
            .mt_transfer_call(
                env.defuse.contract_id(),
                defuse2.account_id(),
                ft2_id.to_string(),
                200,
                None,
                user1.account_id().to_string(),
            )
            .await
            .unwrap();

        user1
            .mt_transfer_call(
                env.defuse.contract_id(),
                defuse2.account_id(),
                ft3_id.to_string(),
                300,
                None,
                user1.account_id().to_string(),
            )
            .await
            .unwrap();
    }

    // At this point, user1 in defuse2 has 100 of `"nep245:defuse.test.near:nep141:ft1.test.near"`, and others
    {
        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft1_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            100
        );

        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft2_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            200
        );

        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft3_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            300
        );
    }

    // To use this:
    // 1. Add this to the resolve function: near_sdk::log!("225a33ac58aee0cf8c6ea225223a237a");
    // 2. Uncomment the key string, which is used to detect this log in promises
    // 3. Uncomment the code after mt_withdraw calls, and it will print the gas values
    // let key_string = "225a33ac58aee0cf8c6ea225223a237a";

    // Now we do a withdraw of ft1 from defuse2, which will trigger a transfer from defuse2 account in defuse, to user2
    {
        let tokens: Vec<(String, u128)> = vec![(ft1_id.to_string(), 10)];

        let (_amounts, _test_log) = user1
            .defuse_mt_withdraw(
                defuse2.account_id(),
                env.defuse.contract_id(),
                user2.account_id(),
                tokens.iter().cloned().map(|v| v.0),
                tokens.iter().map(|v| v.1),
                None,
                None,
            )
            .await
            .unwrap();

        // let receipt_logs = test_log
        //     .logs_and_gas_burnt_in_receipts()
        //     .iter()
        //     .filter(|(a, _b)| a.iter().any(|s| s.contains(key_string)))
        //     .collect::<Vec<_>>();
        // assert_eq!(receipt_logs.len(), 1);

        // println!("Cost with token count 1: {}", receipt_logs[0].1);
    }

    // Now user1 in defuse2 has 90 tokens left of `"nep245:defuse.test.near:nep141:ft1.test.near"`
    {
        // Only ft1 balance changes
        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft1_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            90
        );

        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft2_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            200
        );

        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft3_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            300
        );
    }

    // Now we do a withdraw of ft1 and ft2 from defuse2, which will trigger a transfer from defuse2 account in defuse, to user2
    {
        let tokens: Vec<(String, u128)> = vec![(ft1_id.to_string(), 10), (ft2_id.to_string(), 20)];

        let (_amounts, _test_log) = user1
            .defuse_mt_withdraw(
                defuse2.account_id(),
                env.defuse.contract_id(),
                user2.account_id(),
                tokens.iter().cloned().map(|v| v.0),
                tokens.iter().map(|v| v.1),
                None,
                None,
            )
            .await
            .unwrap();

        // let receipt_logs = test_log
        //     .logs_and_gas_burnt_in_receipts()
        //     .iter()
        //     .filter(|(a, _b)| a.iter().any(|s| s.contains(key_string)))
        //     .collect::<Vec<_>>();
        // assert_eq!(receipt_logs.len(), 1);

        // println!("Cost with token count 2: {}", receipt_logs[0].1);
    }

    // Now we do a withdraw of ft1, ft2 and ft3 from defuse2, which will trigger a transfer from defuse2 account in defuse, to user2
    {
        let tokens: Vec<(String, u128)> = vec![
            (ft1_id.to_string(), 10),
            (ft2_id.to_string(), 20),
            (ft3_id.to_string(), 30),
        ];

        let (_amounts, _test_log) = user1
            .defuse_mt_withdraw(
                defuse2.account_id(),
                env.defuse.contract_id(),
                user2.account_id(),
                tokens.iter().cloned().map(|v| v.0),
                tokens.iter().map(|v| v.1),
                None,
                None,
            )
            .await
            .unwrap();

        // let receipt_logs = test_log
        //     .logs_and_gas_burnt_in_receipts()
        //     .iter()
        //     .filter(|(a, _b)| a.iter().any(|s| s.contains(key_string)))
        //     .collect::<Vec<_>>();
        // assert_eq!(receipt_logs.len(), 1);

        // println!("Cost with token count 3: {}", receipt_logs[0].1);
    }

    // We ensure the math is sound after the last two withdrawals
    {
        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft1_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            70
        );

        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft2_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            160
        );

        assert_eq!(
            defuse2_mt
                .mt_balance_of(MtBalanceOfArgs {
                    account_id: user1.account_id(),
                    token_id: &TokenId::Nep245(Nep245TokenId::new(
                        env.defuse.contract_id().to_owned(),
                        ft3_id.to_string()
                    ))
                    .to_string(),
                })
                .await
                .unwrap()
                .0,
            270
        );
    }
}

#[derive(Debug, Clone)]
struct MtTransferCallExpectation {
    action: StubAction,
    intent_transfer_amounts: Option<Vec<u128>>,
    refund_if_fails: bool,
    expected_sender_mt_balances: Vec<u128>,
    expected_receiver_mt_balances: Vec<u128>,
}

#[rstest]
#[case::receiver_accepts_all_tokens_no_refund(MtTransferCallExpectation {
    action: StubAction::ReturnValue(0.into()),
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![0],
    expected_receiver_mt_balances: vec![1000],
})]
#[case::receiver_requests_partial_refund_300_of_1000(MtTransferCallExpectation {
    action: StubAction::ReturnValue(300.into()),
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![300],
    expected_receiver_mt_balances: vec![700],
})]
#[case::receiver_requests_excessive_refund_capped_at_transferred_amount(MtTransferCallExpectation {
    action: StubAction::ReturnValue(2_000.into()),
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![1_000],
    expected_receiver_mt_balances: vec![0],
})]
#[case::receiver_panics_no_refund_sender_loses_tokens(MtTransferCallExpectation {
    action: StubAction::Panic,
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![1000],
    expected_receiver_mt_balances: vec![0],
})]
#[case::receiver_returns_oversized_data_no_refund_sender_loses_tokens(MtTransferCallExpectation {
    action: StubAction::MaliciousReturn,
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![1000],
    expected_receiver_mt_balances: vec![0],
})]
#[tokio::test]
async fn mt_transfer_call_calls_mt_on_transfer_single_token(
    #[case] expectation: MtTransferCallExpectation,
    #[with(Env::builder().deployer_as_super_admin())]
    #[future(awt)]
    env: Env,
) {
    let (user, intent_receiver, ft) =
        futures::join!(env.create_user(), env.create_user(), env.create_token());

    // Deploy second defuse instance as the receiver
    let defuse2 = env
        .deploy_defuse(
            "defuse2",
            DefuseConfig {
                wnear_id: env.wnear.contract_id().clone(),
                fees: FeesConfig {
                    fee: Pips::ZERO,
                    fee_collector: env.account_id().clone(),
                },
                roles: RolesConfig::default(),
            },
            DEFUSE_WASM.clone(),
        )
        .await;

    // Deploy stub receiver for testing mt_on_transfer behavior
    let receiver = env
        .deploy_sub_contract(
            "receiver_stub",
            NearToken::from_near(100),
            MT_RECEIVER_STUB_WASM.to_vec(),
            None,
        )
        .await
        .unwrap();

    // Register receiver's public key in defuse2 so it can execute intents
    receiver
        .defuse_add_public_key(
            defuse2.account_id(),
            receiver.signer().unwrap().public_key(),
        )
        .await
        .unwrap();

    env.initial_ft_storage_deposit(
        vec![
            user.account_id(),
            receiver.account_id(),
            intent_receiver.account_id(),
        ],
        vec![ft.contract_id()],
    )
    .await;

    let ft_id = TokenId::from(Nep141TokenId::new(ft.contract_id().clone()));
    // Fund user with tokens in defuse1
    env.defuse_ft_deposit_to(ft.contract_id(), 1000, user.account_id(), None)
        .await
        .unwrap();

    // Get the nep245 token id for defuse1's wrapped token in defuse2
    let nep245_ft_id = TokenId::Nep245(Nep245TokenId::new(
        env.defuse.contract_id().clone(),
        ft_id.to_string(),
    ));

    // Build transfer intent if specified
    let intents = match &expectation.intent_transfer_amounts {
        Some(amounts) if !amounts.is_empty() => {
            vec![
                receiver
                    .sign_defuse_payload_default(
                        &env.contract::<Defuse>(defuse2.account_id()),
                        [Transfer {
                            receiver_id: intent_receiver.account_id().clone(),
                            tokens: Amounts::new(
                                std::iter::once((nep245_ft_id.clone(), amounts[0])).collect(),
                            ),
                            memo: None,
                            notification: None,
                        }],
                    )
                    .await
                    .unwrap(),
            ]
        }
        _ => vec![],
    };

    let deposit_message = if intents.is_empty() {
        DepositMessage {
            receiver_id: receiver.account_id().clone(),
            action: Some(DepositAction::Notify(NotifyOnTransfer::new(
                serde_json::to_string(&expectation.action).unwrap(),
            ))),
        }
    } else {
        DepositMessage {
            receiver_id: receiver.account_id().clone(),
            action: Some(DepositAction::Execute(ExecuteIntents {
                execute_intents: intents,
                refund_if_fails: expectation.refund_if_fails,
            })),
        }
    };

    // Transfer from defuse1 to defuse2 using mt_transfer_call
    user.mt_transfer_call(
        env.defuse.contract_id(),
        defuse2.account_id(),
        &ft_id.to_string(),
        1000,
        None,
        serde_json::to_string(&deposit_message).unwrap(),
    )
    .await
    .unwrap();

    // Check balances in defuse1 (original sender)
    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        expectation.expected_sender_mt_balances[0],
        "Sender balance in defuse1 should match expected"
    );

    // Check balances in defuse2 (receiver) - token is wrapped as NEP-245
    assert_eq!(
        env.contract::<Mt>(defuse2.account_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: receiver.account_id(),
                token_id: &nep245_ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        expectation.expected_receiver_mt_balances[0],
        "Receiver balance in defuse2 should match expected"
    );
}

#[rstest]
#[case::nothing_to_refund_multi_token(MtTransferCallExpectation {
    action: StubAction::ReturnValues(vec![0.into(), 0.into()]),
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![0, 0],
    expected_receiver_mt_balances: vec![1000, 2000],
})]
#[case::partial_refund_first_token(MtTransferCallExpectation {
    action: StubAction::ReturnValues(vec![300.into(), 0.into()]),
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![300, 0],
    expected_receiver_mt_balances: vec![700, 2000],
})]
#[case::malicious_refund_multi_token(MtTransferCallExpectation {
    action: StubAction::ReturnValues(vec![3_000.into(), 3_000.into()]),
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![1000, 2000],
    expected_receiver_mt_balances: vec![0, 0],
})]
#[case::receiver_panics_multi_token(MtTransferCallExpectation {
    action: StubAction::Panic,
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![1000, 2000],
    expected_receiver_mt_balances: vec![0, 0],
})]
#[case::malicious_receiver_multi_token(MtTransferCallExpectation {
    action: StubAction::MaliciousReturn,
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![1000, 2000],
    expected_receiver_mt_balances: vec![0, 0],
})]
#[case::wrong_length_return_too_short(MtTransferCallExpectation {
    action: StubAction::ReturnValues(vec![100.into()]),
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![1000, 2000],
    expected_receiver_mt_balances: vec![0, 0],
})]
#[case::wrong_length_return_too_long(MtTransferCallExpectation {
    action: StubAction::ReturnValues(vec![100.into(), 200.into(), 300.into()]),
    intent_transfer_amounts: None,
    refund_if_fails: true,
    expected_sender_mt_balances: vec![1000, 2000],
    expected_receiver_mt_balances: vec![0, 0],
})]
#[tokio::test]
async fn mt_transfer_call_calls_mt_on_transfer_multi_token(
    #[case] expectation: MtTransferCallExpectation,
    #[with(Env::builder().deployer_as_super_admin())]
    #[future(awt)]
    env: Env,
) {
    let (user, intent_receiver, ft1, ft2) = futures::join!(
        env.create_user(),
        env.create_user(),
        env.create_token(),
        env.create_token()
    );

    // Deploy second defuse instance as the receiver
    let defuse2 = env
        .deploy_defuse(
            "defuse2",
            DefuseConfig {
                wnear_id: env.wnear.contract_id().clone(),
                fees: FeesConfig {
                    fee: Pips::ZERO,
                    fee_collector: env.account_id().clone(),
                },
                roles: RolesConfig::default(),
            },
            DEFUSE_WASM.clone(),
        )
        .await;

    // Deploy stub receiver for testing mt_on_transfer behavior
    let receiver = env
        .deploy_sub_contract(
            "receiver_stub",
            NearToken::from_near(100),
            MT_RECEIVER_STUB_WASM.to_vec(),
            None,
        )
        .await
        .unwrap();

    // Register receiver's public key in defuse2 so it can execute intents
    receiver
        .defuse_add_public_key(
            defuse2.account_id(),
            receiver.signer().unwrap().public_key(),
        )
        .await
        .unwrap();

    env.initial_ft_storage_deposit(
        vec![
            user.account_id(),
            receiver.account_id(),
            intent_receiver.account_id(),
        ],
        vec![ft1.contract_id(), ft2.contract_id()],
    )
    .await;

    let ft1_id = TokenId::from(Nep141TokenId::new(ft1.contract_id().clone()));
    let ft2_id = TokenId::from(Nep141TokenId::new(ft2.contract_id().clone()));

    // Fund user with tokens in defuse1
    env.defuse_ft_deposit_to(ft1.contract_id(), 1000, user.account_id(), None)
        .await
        .unwrap();
    env.defuse_ft_deposit_to(ft2.contract_id(), 2000, user.account_id(), None)
        .await
        .unwrap();

    // Get the nep245 token ids for defuse1's wrapped tokens in defuse2
    let nep245_ft1_id = TokenId::Nep245(Nep245TokenId::new(
        env.defuse.contract_id().clone(),
        ft1_id.to_string(),
    ));
    let nep245_ft2_id = TokenId::Nep245(Nep245TokenId::new(
        env.defuse.contract_id().clone(),
        ft2_id.to_string(),
    ));

    // Build transfer intents if specified
    let intents = if let Some(amounts) = &expectation.intent_transfer_amounts {
        let mut intent_map = std::collections::BTreeMap::new();

        if let Some(&amount1) = amounts.first() {
            intent_map.insert(nep245_ft1_id.clone(), amount1);
        }
        if let Some(&amount2) = amounts.get(1) {
            intent_map.insert(nep245_ft2_id.clone(), amount2);
        }

        vec![
            receiver
                .sign_defuse_payload_default(
                    &env.contract::<Defuse>(defuse2.account_id()),
                    [Transfer {
                        receiver_id: intent_receiver.account_id().clone(),
                        tokens: Amounts::new(intent_map),
                        memo: None,
                        notification: None,
                    }],
                )
                .await
                .unwrap(),
        ]
    } else {
        vec![]
    };

    let deposit_message = if intents.is_empty() {
        DepositMessage {
            receiver_id: receiver.account_id().clone(),
            action: Some(DepositAction::Notify(NotifyOnTransfer::new(
                serde_json::to_string(&expectation.action).unwrap(),
            ))),
        }
    } else {
        DepositMessage {
            receiver_id: receiver.account_id().clone(),
            action: Some(DepositAction::Execute(ExecuteIntents {
                execute_intents: intents,
                refund_if_fails: expectation.refund_if_fails,
            })),
        }
    };

    // Transfer both tokens from user in defuse1 to defuse2 using batch transfer
    user.mt_batch_transfer_call(
        env.defuse.contract_id(),
        defuse2.account_id(),
        vec![ft1_id.to_string(), ft2_id.to_string()],
        vec![1000, 2000],
        None,
        serde_json::to_string(&deposit_message).unwrap(),
    )
    .await
    .unwrap();

    // Check balances in defuse1 (original sender)
    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft1_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        expectation.expected_sender_mt_balances[0],
        "Sender balance for ft1 in defuse1 should match expected"
    );
    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft2_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        expectation.expected_sender_mt_balances[1],
        "Sender balance for ft2 in defuse1 should match expected"
    );

    // Check balances in defuse2 (receiver)
    assert_eq!(
        env.contract::<Mt>(defuse2.account_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: receiver.account_id(),
                token_id: &nep245_ft1_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        expectation.expected_receiver_mt_balances[0],
        "Receiver balance for ft1 in defuse2 should match expected"
    );
    assert_eq!(
        env.contract::<Mt>(defuse2.account_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: receiver.account_id(),
                token_id: &nep245_ft2_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        expectation.expected_receiver_mt_balances[1],
        "Receiver balance for ft2 in defuse2 should match expected"
    );
}

#[rstest]
#[tokio::test]
async fn mt_transfer_call_circullar_callback(
    #[with(Env::builder().deployer_as_super_admin())]
    #[future(awt)]
    env: Env,
) {
    let (user, ft) = futures::join!(env.create_user(), env.create_token());

    let defuse2 = env
        .deploy_defuse(
            "defuse2",
            DefuseConfig {
                wnear_id: env.wnear.contract_id().clone(),
                fees: FeesConfig {
                    fee: Pips::ZERO,
                    fee_collector: env.account_id().clone(),
                },
                roles: RolesConfig::default(),
            },
            DEFUSE_WASM.clone(),
        )
        .await;

    env.initial_ft_storage_deposit(vec![user.account_id()], vec![ft.contract_id()])
        .await;

    let ft_id = TokenId::from(Nep141TokenId::new(ft.contract_id().clone()));

    // Step 1: Deposit tokens to user in defuse1
    env.defuse_ft_deposit_to(ft.contract_id(), 1000, user.account_id(), None)
        .await
        .unwrap();

    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        1000,
        "User should have 1000 tokens in defuse1"
    );

    // NOTE: Test circular callback case: defuse1 → defuse2 → defuse1
    // Set receiver_id to defuse1 to create circular callback
    // With empty inner message to avoid further callbacks
    let deposit_message = DepositMessage {
        receiver_id: env.defuse.contract_id().clone(), // Circular: back to defuse1
        action: Some(DepositAction::Notify(NotifyOnTransfer::new(
            serde_json::to_string(&DepositMessage::new(user.account_id().clone())).unwrap(),
        ))),
    };

    // Get the nep245 token id for defuse1's wrapped token in defuse2
    let nep245_ft_id = TokenId::Nep245(Nep245TokenId::new(
        env.defuse.contract_id().clone(),
        ft_id.to_string(),
    ));

    let refund_amount = user
        .mt_transfer_call(
            env.defuse.contract_id(),
            defuse2.account_id(),
            &ft_id.to_string(),
            600,
            None,
            serde_json::to_string(&deposit_message).unwrap(),
        )
        .await
        .expect("mt_transfer_call should succeed");

    // The inner callback to defuse1 should succeed and keep all tokens
    assert_eq!(
        *refund_amount.1.first().unwrap(),
        600,
        "Should return 600 (amount used) since tokens were successfully deposited in circular callback"
    );

    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        400,
        "User should have 400 tokens in defuse1 after transfer"
    );

    // In the circular callback flow:
    // 1. defuse2 receives 600 tokens, deposits them to defuse1 (receiver_id in outer message)
    // 2. defuse2 calls defuse1.mt_on_transfer as a notification (with inner message)
    // 3. defuse1.mt_on_transfer processes the notification and returns no refund
    //
    // IMPORTANT: mt_on_transfer is just a notification callback, it doesn't transfer tokens again.
    // The tokens are already deposited in defuse2, owned by defuse1.

    assert_eq!(
        env.contract::<Mt>(defuse2.account_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: env.defuse.contract_id(),
                token_id: &nep245_ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        600,
        "defuse1 should have 600 wrapped tokens in defuse2 after circular callback"
    );

    assert_eq!(
        env.contract::<Mt>(defuse2.account_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &nep245_ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        0,
        "User should have 0 wrapped tokens in defuse2"
    );
}

#[rstest]
#[tokio::test]
async fn mt_transfer_call_circullar_deposit(
    #[with(Env::builder().deployer_as_super_admin())]
    #[future(awt)]
    env: Env,
) {
    let (user, ft) = futures::join!(env.create_user(), env.create_token());

    let defuse2 = env
        .deploy_defuse(
            "defuse2",
            DefuseConfig {
                wnear_id: env.wnear.contract_id().clone(),
                fees: FeesConfig {
                    fee: Pips::ZERO,
                    fee_collector: env.account_id().clone(),
                },
                roles: RolesConfig::default(),
            },
            DEFUSE_WASM.clone(),
        )
        .await;

    env.initial_ft_storage_deposit(vec![user.account_id()], vec![ft.contract_id()])
        .await;

    // Step 1: Deposit tokens to defuse2 in defuse1
    env.defuse_ft_deposit_to(
        ft.contract_id(),
        1000,
        defuse2.account_id(),
        // NOTE: Test circular callback case: defuse2 → defuse1
        // Set receiver_id to defuse1 to create circular callback
        // With empty inner message to avoid further callbacks
        DepositAction::Notify(NotifyOnTransfer::new(
            serde_json::to_string(&DepositMessage {
                receiver_id: env.defuse.contract_id().clone(), // Circular: back to defuse1
                action: Some(DepositAction::Notify(NotifyOnTransfer::new(
                    serde_json::to_string(&DepositMessage::new(user.account_id().clone())).unwrap(),
                ))),
            })
            .unwrap(),
        )),
    )
    .await
    .unwrap();

    // Get the nep245 token id for defuse1
    let defuse1_ft_id: TokenId = Nep141TokenId::new(ft.contract_id().clone()).into();

    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: defuse2.account_id(),
                token_id: &defuse1_ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        1000,
        "defuse2 should have 1000 tokens in defuse1"
    );

    let defuse2_nep245_ft_id = TokenId::Nep245(Nep245TokenId::new(
        env.defuse.contract_id().clone(),
        defuse1_ft_id.to_string(),
    ));

    assert_eq!(
        env.contract::<Mt>(defuse2.account_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: env.defuse.contract_id(),
                token_id: &defuse2_nep245_ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        1000,
        "defuse1 should have 1000 tokens in defuse2 after wrapping"
    );

    let defuse1_defuse2_nep245_ft_id = TokenId::Nep245(Nep245TokenId::new(
        defuse2.account_id().clone(),
        defuse2_nep245_ft_id.to_string(),
    ));

    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &defuse1_defuse2_nep245_ft_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        1000,
        "user should have 1000 tokens in defuse1 after wrapping via defuse2"
    );
}

#[allow(clippy::too_many_lines)]
#[rstest]
#[tokio::test]
async fn mt_transfer_call_duplicate_tokens_with_stub_execute_and_refund(
    #[with(Env::builder().deployer_as_super_admin())]
    #[future(awt)]
    env: Env,
) {
    let (user, another_receiver, ft1, ft2) = futures::join!(
        env.create_user(),
        env.create_user(),
        env.create_token(),
        env.create_token()
    );

    let defuse2 = env
        .deploy_defuse(
            "defuse2",
            DefuseConfig {
                wnear_id: env.wnear.contract_id().clone(),
                fees: FeesConfig {
                    fee: Pips::ZERO,
                    fee_collector: env.account_id().clone(),
                },
                roles: RolesConfig::default(),
            },
            DEFUSE_WASM.clone(),
        )
        .await;

    let stub_receiver = env
        .deploy_sub_contract(
            "receiver_stub",
            NearToken::from_near(100),
            MT_RECEIVER_STUB_WASM.to_vec(),
            None,
        )
        .await
        .unwrap();

    // Register stub's public key in defuse2 so it can execute intents
    stub_receiver
        .defuse_add_public_key(
            defuse2.account_id(),
            stub_receiver.signer().unwrap().public_key(),
        )
        .await
        .unwrap();

    env.initial_ft_storage_deposit(
        vec![user.account_id(), stub_receiver.account_id()],
        vec![ft1.contract_id(), ft2.contract_id()],
    )
    .await;

    let transfer_amounts = [1000, 2000, 3000].map(U128::from).to_vec();
    let refund_amounts = vec![1000, 2000, 1000];

    let ft1_id = TokenId::from(Nep141TokenId::new(ft1.contract_id().clone()));
    let ft2_id = TokenId::from(Nep141TokenId::new(ft2.contract_id().clone()));

    let nep245_ft1_id = TokenId::Nep245(Nep245TokenId::new(
        env.defuse.contract_id().clone(),
        ft1_id.to_string(),
    ));
    let nep245_ft2_id = TokenId::Nep245(Nep245TokenId::new(
        env.defuse.contract_id().clone(),
        ft2_id.to_string(),
    ));

    env.defuse_ft_deposit_to(ft1.contract_id(), 4000, user.account_id(), None)
        .await
        .unwrap();
    env.defuse_ft_deposit_to(ft2.contract_id(), 2000, user.account_id(), None)
        .await
        .unwrap();

    let stub_action = StubAction::ExecuteAndRefund {
        multipayload: stub_receiver
            .sign_defuse_payload_default(
                &env.contract::<Defuse>(defuse2.account_id()),
                [Transfer {
                    receiver_id: another_receiver.account_id().clone(),
                    tokens: Amounts::new([(nep245_ft1_id.clone(), 2000)].into()),
                    memo: None,
                    notification: None,
                }],
            )
            .await
            .unwrap(),
        refund_amounts: refund_amounts.iter().copied().map(U128).collect(),
    };

    let deposit_message = DepositMessage {
        receiver_id: stub_receiver.account_id().clone(),
        action: Some(DepositAction::Notify(NotifyOnTransfer::new(
            serde_json::to_string(&stub_action).unwrap(),
        ))),
    };

    let result = user
        .mt_batch_transfer_call(
            env.defuse.contract_id(),
            defuse2.account_id(),
            vec![ft1_id.to_string(), ft2_id.to_string(), ft1_id.to_string()],
            transfer_amounts.into_iter().map(|a| a.0),
            None,
            serde_json::to_string(&deposit_message).unwrap(),
        )
        .await
        .unwrap()
        .0;

    // Token IDs for events
    let ft_token_ids = [ft1_id.to_string(), ft2_id.to_string(), ft1_id.to_string()];
    let mt_token_ids = [
        nep245_ft1_id.to_string(),
        nep245_ft2_id.to_string(),
        nep245_ft1_id.to_string(),
    ];

    let burn_events = [MtBurnEvent {
        owner_id: Cow::Borrowed(stub_receiver.account_id().as_ref()),
        authorized_id: None,
        token_ids: Cow::Borrowed(&mt_token_ids),
        amounts: Cow::Borrowed(&refund_amounts),
        memo: Some(Cow::Borrowed(REFUND_MEMO)),
    }];
    let expected_mt_burn = MtEvent::MtBurn(Cow::Borrowed(&burn_events));

    let transfer_events = [MtTransferEvent {
        authorized_id: None,
        old_owner_id: Cow::Borrowed(defuse2.account_id().as_ref()),
        new_owner_id: Cow::Borrowed(user.account_id().as_ref()),
        token_ids: Cow::Borrowed(&ft_token_ids),
        amounts: Cow::Borrowed(&refund_amounts), // Use capped refund amounts
        memo: Some(Cow::Borrowed(REFUND_MEMO)),
    }];
    let expected_mt_transfer = MtEvent::MtTransfer(Cow::Borrowed(&transfer_events));

    assert_a_contains_b(
        result.logs(),
        [
            expected_mt_burn.to_nep297_event().to_event_log(),
            expected_mt_transfer.to_nep297_event().to_event_log(),
        ],
    );

    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft1_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        2000,
        "User should have: 1000 (first refund) + 1000 (third refund capped) = 2000 of token1"
    );

    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft2_id.to_string(),
            })
            .await
            .unwrap()
            .0,
        2000,
        "User should have: 2000 (second refund) = 2000 of token2 (all refunded)"
    );
}
