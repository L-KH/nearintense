#![allow(clippy::cloned_ref_to_slice_refs)]

use defuse_core::{intents::MaybeIntentEvent, payload::Payload};
use defuse_randomness::{Rng, RngExt};
use defuse_sandbox::{
    extensions::{
        defuse::{
            DefuseExt, DefuseSignerExt, MultiPayloadArgs,
            core::{
                Nonce, Timestamp,
                accounts::{AccountEvent, NonceEvent},
                amounts::Amounts,
                events::DefuseEvent,
                intents::{DefuseIntents, tokens::Transfer},
                token_id::{TokenId, nep141::Nep141TokenId},
                tokens::TransferEvent,
            },
        },
        mt::{Mt, MtBalanceOfArgs},
    },
    kit::{AccountId, AccountIdRef, CryptoHash, sandbox::SandboxConfig},
};
use defuse_test_utils::random::rng;
use near_sdk::events::AsNep297Event;
use rstest::rstest;
use std::borrow::Cow;

use crate::tests::defuse::env::{Env, EnvBuilder, env};

pub struct AccountNonceIntentEvent(AccountId, Nonce, CryptoHash);

impl AccountNonceIntentEvent {
    pub fn new(
        account_id: impl AsRef<AccountIdRef> + Clone,
        nonce: Nonce,
        payload: &impl Payload,
    ) -> Self {
        let acc = account_id.as_ref().to_owned();
        Self(acc, nonce, payload.hash().into())
    }

    pub fn into_event(self) -> DefuseEvent<'static> {
        DefuseEvent::IntentsExecuted(
            vec![MaybeIntentEvent::new_intent(
                AccountEvent::new(self.0, NonceEvent::new(self.1)),
                *self.2.as_bytes(),
            )]
            .into(),
        )
    }
}

mod ft_withdraw;
#[cfg(feature = "imt")]
mod imt_burn;
#[cfg(feature = "imt")]
mod imt_mint;
mod legacy_nonce;
mod native_withdraw;
mod public_key;
mod relayers;
mod simulate;
mod token_diff;
mod transfer;

#[rstest]
#[tokio::test]
async fn simulate_is_view_method(#[future(awt)] env: Env, #[notrace] mut rng: impl Rng) {
    let (user, other_user, ft) =
        futures::join!(env.create_user(), env.create_user(), env.create_token());

    let ft_id = TokenId::from(Nep141TokenId::new(ft.contract_id().clone()));

    env.initial_ft_storage_deposit(
        vec![user.account_id(), other_user.account_id()],
        vec![ft.contract_id()],
    )
    .await;

    // deposit
    env.defuse_ft_deposit_to(ft.contract_id(), 1000, user.account_id(), None)
        .await
        .unwrap();

    let nonce = rng.random();

    let transfer_intent = Transfer {
        receiver_id: other_user.account_id().clone(),
        tokens: Amounts::new(std::iter::once((ft_id.clone(), 1000)).collect()),
        memo: None,
        notification: None,
    };

    let transfer_intent_payload = user
        .sign_defuse_message(
            env.defuse.contract_id(),
            nonce,
            Timestamp::MAX,
            DefuseIntents {
                intents: vec![transfer_intent.clone().into()],
            },
        )
        .await;
    let result = env
        .defuse
        .simulate_intents(MultiPayloadArgs {
            signed: &[transfer_intent_payload.clone()],
        })
        .await
        .unwrap();

    assert_eq!(result.report.intents_executed.len(), 1);

    // Prepare expected transfer event
    let expected_log = DefuseEvent::Transfer(Cow::Owned(vec![MaybeIntentEvent::new_intent(
        AccountEvent {
            account_id: user.account_id().clone().into(),
            event: TransferEvent {
                receiver_id: Cow::Borrowed(&transfer_intent.receiver_id),
                tokens: transfer_intent.tokens,
                memo: transfer_intent.memo.as_deref().map(Cow::Borrowed),
            },
        },
        transfer_intent_payload.hash(),
    )]))
    .to_nep297_event()
    .to_event_log();

    assert!(result.report.logs.iter().any(|log| log == &expected_log));
    assert_eq!(
        result
            .report
            .intents_executed
            .first()
            .unwrap()
            .event
            .event
            .nonce,
        nonce
    );
    result.into_result().unwrap();

    // Verify balances haven't changed (simulate is a view method)
    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft_id.to_string()
            })
            .await
            .unwrap()
            .0,
        1000
    );
    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: other_user.account_id(),
                token_id: &ft_id.to_string()
            })
            .await
            .unwrap()
            .0,
        0
    );
}

#[rstest]
#[tokio::test]
async fn webauthn() {
    const ROOT_ID: &AccountIdRef = AccountIdRef::new_or_panic("test.near");
    const DEFUSE_NAME: &str = "defuse";
    const POA_FACTORY_NAME: &str = "poa-factory";
    const SIGNER_ID: &AccountIdRef =
        AccountIdRef::new_or_panic("0x3602b546589a8fcafdce7fad64a46f91db0e4d50");

    let sandbox = SandboxConfig::builder().root_account(ROOT_ID).fresh().await;

    let env = EnvBuilder::default()
        .defuse_name(DEFUSE_NAME)
        .poa_factory_name(POA_FACTORY_NAME)
        .build(sandbox.client())
        .await;

    let (user, ft) = futures::join!(
        env.create_named_user("user1"),
        env.create_named_token("ft1")
    );

    let ft_id = TokenId::from(Nep141TokenId::new(ft.contract_id().clone()));

    env.initial_ft_storage_deposit(vec![user.account_id()], vec![ft.contract_id()])
        .await;

    // deposit
    env.defuse_ft_deposit_to(ft.contract_id(), 2000, SIGNER_ID, None)
        .await
        .unwrap();

    env
        .defuse_simulate_and_execute_intents(env.defuse.contract_id(), [serde_json::from_str(r#"{
  "standard": "webauthn",
  "payload": "{\"signer_id\":\"0x3602b546589a8fcafdce7fad64a46f91db0e4d50\",\"verifying_contract\":\"defuse.test.near\",\"deadline\":\"2050-03-30T00:00:00Z\",\"nonce\":\"A3nsY1GMVjzyXL3mUzOOP3KT+5a0Ruy+QDNWPhchnxM=\",\"intents\":[{\"intent\":\"transfer\",\"receiver_id\":\"user1.test.near\",\"tokens\":{\"nep141:ft1.poa-factory.test.near\":\"1000\"}}]}",
  "public_key": "p256:2V8Np9vGqLiwVZ8qmMmpkxU7CTRqje4WtwFeLimSwuuyF1rddQK5fELiMgxUnYbVjbZHCNnGc6fAe4JeDcVxgj3Q",
  "signature": "p256:2wpTbs61923xQU9L4mqBGSdHSdv5mqMn3zRA2tFmDirm8t4mx1PYAL7Vhe9uta4WMbHoMMTBZ8KQSM7nWug3Nrc7",
  "client_data_json": "{\"type\":\"webauthn.get\",\"challenge\":\"DjS-6fxaPS3avW-4ls8dDYAynCmsAXWCF86cJBTkHbs\",\"origin\":\"https://defuse-widget-git-feat-passkeys-defuse-94bbc1b2.vercel.app\"}",
  "authenticator_data": "933cQogpBzE3RSAYSAkfWoNEcBd3X84PxE8iRrRVxMgdAAAAAA=="
}"#).unwrap(), serde_json::from_str(r#"{
  "standard": "webauthn",
  "payload": "{\"signer_id\":\"0x3602b546589a8fcafdce7fad64a46f91db0e4d50\",\"verifying_contract\":\"defuse.test.near\",\"deadline\":\"2050-03-30T00:00:00Z\",\"nonce\":\"B3nsY1GMVjzyXL3mUzOOP3KT+5a0Ruy+QDNWPhchnxM=\",\"intents\":[{\"intent\":\"transfer\",\"receiver_id\":\"user1.test.near\",\"tokens\":{\"nep141:ft1.poa-factory.test.near\":\"1000\"}}]}",
  "public_key": "p256:2V8Np9vGqLiwVZ8qmMmpkxU7CTRqje4WtwFeLimSwuuyF1rddQK5fELiMgxUnYbVjbZHCNnGc6fAe4JeDcVxgj3Q",
  "signature": "p256:5Zq1w2ntVi5EowuKPnaSyuM2XB3JsQZub5CXB1fHsP6MWMSV1RXEoqpgVn5kNK43ZiUoXGBKVvUSS3DszwWCWgG6",
  "client_data_json": "{\"type\":\"webauthn.get\",\"challenge\":\"6ULo-LNIjd8Gh1mdxzUdHzv2AuGDWMchOORdDnaLXHc\",\"origin\":\"https://defuse-widget-git-feat-passkeys-defuse-94bbc1b2.vercel.app\"}",
  "authenticator_data": "933cQogpBzE3RSAYSAkfWoNEcBd3X84PxE8iRrRVxMgdAAAAAA=="
}"#).unwrap()])
        .await
        .unwrap();

    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: user.account_id(),
                token_id: &ft_id.to_string()
            })
            .await
            .unwrap()
            .0,
        2000
    );
    assert_eq!(
        env.contract::<Mt>(env.defuse.contract_id())
            .mt_balance_of(MtBalanceOfArgs {
                account_id: SIGNER_ID,
                token_id: &ft_id.to_string()
            })
            .await
            .unwrap()
            .0,
        0
    );
}

// #[tokio::test]
// #[rstest]
// #[trace]
// async fn ton_connect_sign_intent_example(#[future(awt)] env: Env) {
//     pub const DUMMY_MSG_ADDRESS: MsgAddress = MsgAddress {
//         workchain_id: 1234i32,
//         address: [12u8; 32],
//     };

//     let env: Env = Env::builder().build().await;

//     let ft_id: AccountId = "ft.test.near".parse().unwrap();

//     let intents = DefuseIntents {
//         intents: [FtWithdraw {
//             token: ft_id,
//             receiver_id: "bob.near".parse().unwrap(),
//             amount: 1000.into(),
//             memo: None,
//             msg: None,
//             storage_deposit: None,
//             min_gas: None,
//         }
//         .into()]
//         .into(),
//     };
//     let nonce = env.get_unique_nonce(None).await.unwrap();

//     let payload = defuse::core::ton_connect::TonConnectPayload {
//         address: DUMMY_MSG_ADDRESS,
//         domain: "example.com".to_string(),
//         timestamp: defuse_near_utils::time::now(),
//         payload: defuse::core::ton_connect::TonConnectPayloadSchema::text(
//             serde_json::to_string(&DefusePayload {
//                 signer_id: "alice.near".parse().unwrap(),
//                 verifying_contract: "intent.near".parse().unwrap(),
//                 deadline: Deadline::timeout(std::time::Duration::from_secs(120)),
//                 nonce,
//                 message: intents,
//             })
//             .unwrap(),
//         ),
//     };

//     let account = env.create_user().await;
//     let signed = account.sign_ton_connect(payload);

//     let _decoded_payload: DefusePayload<DefuseIntents> = signed.extract_defuse_payload().unwrap();
// }
