use defuse_core::payload::Payload;
use defuse_sandbox::extensions::defuse::{
    DefuseExt, DefuseSignerExt, ExtractNonceExt, ToEventLog,
    core::{
        PublicKey,
        accounts::{AccountEvent, PublicKeyEvent},
        events::DefuseEvent,
        intents::{
            MaybeIntentEvent,
            account::{AddPublicKey, RemovePublicKey},
        },
    },
};
use near_sdk::events::AsNep297Event;
use rstest::rstest;
use std::borrow::Cow;

use crate::{
    tests::defuse::{
        env::{Env, env},
        intents::AccountNonceIntentEvent,
        utils::assert_eq_defuse_event_logs,
    },
    utils::fixtures::public_key,
};

#[rstest]
#[trace]
#[tokio::test]
async fn execute_add_public_key_intent(
    #[notrace]
    #[future(awt)]
    env: Env,
    public_key: PublicKey,
) {
    let user = env.create_user().await;

    let new_public_key = public_key;

    let add_public_key_payload = user
        .sign_defuse_payload_default(
            &env.defuse,
            [AddPublicKey {
                public_key: new_public_key,
            }],
        )
        .await
        .unwrap();

    let nonce = add_public_key_payload.extract_nonce().unwrap();

    let (result, _) = env
        .defuse_simulate_and_execute_intents(
            env.defuse.contract_id(),
            [add_public_key_payload.clone()],
        )
        .await
        .unwrap();

    let events = vec![
        DefuseEvent::PublicKeyAdded(MaybeIntentEvent::new_intent(
            AccountEvent::new(
                user.account_id(),
                PublicKeyEvent {
                    public_key: Cow::Borrowed(&new_public_key),
                },
            ),
            add_public_key_payload.hash(),
        ))
        .to_nep297_event()
        .to_event_log(),
        AccountNonceIntentEvent::new(&user.account_id(), nonce, &add_public_key_payload)
            .into_event()
            .to_nep297_event()
            .to_event_log(),
    ];

    assert_eq!(result.logs(), events);
}

#[rstest]
#[trace]
#[tokio::test]
async fn execute_remove_public_key_intent(
    #[notrace]
    #[future(awt)]
    env: Env,
    public_key: PublicKey,
) {
    let user = env.create_user().await;

    let new_public_key = public_key;
    let add_public_key_payload = user
        .sign_defuse_payload_default(
            &env.defuse,
            [AddPublicKey {
                public_key: new_public_key,
            }],
        )
        .await
        .unwrap();
    let _add_nonce = add_public_key_payload.extract_nonce().unwrap();

    env.defuse_simulate_and_execute_intents(env.defuse.contract_id(), [add_public_key_payload])
        .await
        .unwrap();

    let remove_public_key_payload = user
        .sign_defuse_payload_default(
            &env.defuse,
            [RemovePublicKey {
                public_key: new_public_key,
            }],
        )
        .await
        .unwrap();

    let (result, _) = env
        .defuse_simulate_and_execute_intents(
            env.defuse.contract_id(),
            [remove_public_key_payload.clone()],
        )
        .await
        .unwrap();

    assert_eq_defuse_event_logs(remove_public_key_payload.to_event_log(), result.logs());
}
